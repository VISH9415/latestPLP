function alertLogin(){
	alert("Successfully logged in !");
	return true;
	} 

function alertLoginF(){
	alert("login failed!");
	return true;
	} 
