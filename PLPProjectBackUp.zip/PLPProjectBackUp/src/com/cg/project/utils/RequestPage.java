package com.cg.project.utils;

public interface RequestPage {

	String redirectToLoginPage = "home";
	String redirectToErrorPage = "Error";
	String redirectToPage = "Temp";
	String redirectToListPage = "ViewList";
}
